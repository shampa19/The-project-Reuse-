ReUse video demonstration package
=================================

Open index.html in a modern browser, or deploy the entire folder to Netlify Drop.

Important:
- Marketplace photos are bundled locally in assets/ and do not depend on external image hosts.
- Use the demo accounts shown on the sign-in screen.
- This is a front-end prototype for recording a project video. Data is browser-local and payments are simulated.
- Do not present it as a production multi-user service.

For hosting:
1. Zip or extract this folder.
2. Upload the folder to https://app.netlify.com/drop
3. Use the generated public URL for your video demonstration.
